import java.util.ArrayList;
import java.util.List;

public class GestorEmpleados {
    private List<Empleado> listaEmpleados;

    // Constructor
    public GestorEmpleados() {
        listaEmpleados = new ArrayList<>();
    }

    // Método para agregar un empleado
    public void agregarEmpleado(Empleado empleado) {
        listaEmpleados.add(empleado);
    }

    // Método para mostrar todos los empleados
    public void mostrarEmpleados() {
        if (listaEmpleados.isEmpty()) {
            System.out.println("No hay empleados registrados.");
        } else {
            for (Empleado empleado : listaEmpleados) {
                empleado.mostrarInformacion();
                System.out.println("---------------------");
            }
        }
    }
}
